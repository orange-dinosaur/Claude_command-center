# Handoff: restyle "My command center" (Expo / React Native)

## Overview
Nuovo stile visivo per tutta l'app: palette calda terrosa (eucalipto, rosa borgogna, sabbia), font Cormorant Garamond + Karla, logo "Quattro tessere". **Layout, flussi, testi e logica restano quelli del repo**: si cambiano solo token, tipografia, icone app.

## About the Design Files
I file `.dc.html` in `designs/` sono **riferimenti di design in HTML** (prototipi apribili nel browser), non codice da copiare. Vanno ricreati nel codebase esistente (Expo Router + React Native, `ThemedText`, `useTheme`, `StyleSheet`). Ogni `X.dc.html` di pagina importa un `X Phone.dc.html` (il telefono vero e proprio).

## Fidelity
**High-fidelity**: colori, font, dimensioni finali.

## 1. `src/constants/theme.ts`
Sostituire `Colors` (chiavi esistenti invariate + tre nuove):
```ts
export const Colors = {
  light: {
    text: '#2F2A27', textMuted: '#736960',
    background: '#F3EEE7', backgroundElement: '#FBF8F4',
    accent: '#7C8C6E', danger: '#A8452F',
    secondary: '#A14A5A', tertiary: '#D8C6B0', border: '#DED5C9',
    onAccent: '#FBF8F4',
  },
  dark: {
    text: '#ECEAE2', textMuted: '#A2A596',
    background: '#171B17', backgroundElement: '#222822',
    accent: '#A3B592', danger: '#E58A74',
    secondary: '#B35F6D', tertiary: '#E1CFB8', border: '#343B33',
    onAccent: '#171B17',
  },
} as const;
```
`Spacing` invariato. **Testo su accent** (TabBar selezionata, mese selezionato nel picker, SubmitButton, "Nuovo mese", spunta checklist): usare `theme.onAccent` al posto di `backgroundElement`/`background`. In dark `backgroundElement` su accent chiaro non ha contrasto.

## 2. Font
`npx expo install expo-font @expo-google-fonts/cormorant-garamond @expo-google-fonts/karla`
Caricare in `_layout.tsx` con `useFonts` (tenere lo splash fino al caricamento): `CormorantGaramond_600SemiBold`, `Karla_400Regular`, `Karla_500Medium`, `Karla_600SemiBold`, `Karla_700Bold`.

In React Native `fontWeight` non seleziona il file: usare `fontFamily` specifica. `themed-text.tsx`:
```ts
default:  { fontFamily: 'Karla_400Regular', fontSize: 16, lineHeight: 24 },
title:    { fontFamily: 'CormorantGaramond_600SemiBold', fontSize: 36, lineHeight: 40 },
subtitle: { fontFamily: 'CormorantGaramond_600SemiBold', fontSize: 26, lineHeight: 30 },
small:    { fontFamily: 'Karla_400Regular', fontSize: 14, lineHeight: 20 },
```
Ovunque ci sia `fontWeight: 600` su testo Karla → `fontFamily: 'Karla_600SemiBold'` (tool-button title, tab-bar label, SubmitButton). Spunta ✓ checklist → `Karla_700Bold`.
Eccezioni:
- Titoli schermate auth (Accedi, Registrati, …): 40/44.
- Data in Home (`type="subtitle"`): 28/32 Cormorant.
- Nomi mese nella lista closeout: 24/28.
- Testo pulsanti "Nuovo mese" e "Crea …" (oggi `subtitle`): Karla 600 18/24, non serif.

## 3. Logo e icone
Asset in `assets/logo/` (vedi `assets/logo/README.md`).
- `public/`: sostituire `apple-touch-icon.png`, `icon-192.png`, `icon-512.png` con `png/apple-touch-icon-light.png`, `png/icon-192-light.png`, `png/icon-512-light.png`; aggiungere `favicon/favicon.svg`, `favicon/favicon.ico`, i maskable.
- `public/manifest.json`: `background_color: "#F3EEE7"`, aggiungere `"theme_color": "#F3EEE7"` e le icone maskable (snippet nel README del logo).
- `src/app/+html.tsx`: link favicon.svg / .ico / apple-touch-icon + `theme-color` light `#F3EEE7` e dark `#171B17`.
- `app.json`: `icon` → `png/mark-light-1024.png` su fondo (o `icon-512-light` scalata a 1024); `android.adaptiveIcon.backgroundColor` `#F3EEE7`, foreground `mark-light-1024.png`; splash `backgroundColor` `#F3EEE7`, image il simbolo.
- Opzionale (non nel codice attuale): simbolo 56×56 sopra il titolo delle schermate auth, margine sotto 8 (`mark-light`/`mark-dark` in base al tema).

## 4. Schermate (nessun cambio di layout)
Tutte già usano i token: dopo il punto 1–2 si aggiornano da sole. Controllare:
- **Home** (`index.tsx`, `vision-board.tsx`): icona grid_view 28 accent; box vuoto con bordo tratteggiato `textMuted`, radius 20. Il design aggiunge un'icona `add_photo_alternate` 32 accent sopra "Carica la tua vision board" (facoltativa). Sheet: Sostituisci accent, Rimuovi danger, Annulla `text`, separatore 1px `border` (facoltativo).
- **Command center**: tessera `backgroundElement`, radius 20, icona 32 accent, "Esci" danger.
- **Monthly closeout** lista/dettaglio/tab/checklist/domande: invariati, testo su accent → `onAccent`. Campi input: focus ring 2px accent (web).
- **Login / Registrati / Password dimenticata / Nuova password**: invariati; SubmitButton testo `onAccent`, disabled opacity 0.5.
- Backdrop modali: `rgba(0,0,0,0.4)` (in dark è ok anche 0.55).

## Files
- `designs/Font e Palette.dc.html`: storia delle scelte (3a light, 4b dark)
- `designs/Home.dc.html`, `Command Center.dc.html`
- `designs/Monthly Closeout.dc.html` + `Closeout Phone.dc.html`
- `designs/Login.dc.html` + `Login Phone.dc.html`
- `designs/Auth.dc.html` + `Auth Phone.dc.html`
- `designs/Logo.dc.html`, `assets/logo/…`

## Prompt suggerito per Claude Code
> Leggi design_handoff_restyle/README.md e applica il restyle: aggiorna theme.ts, carica i font, aggiorna themed-text e i componenti con testo su accent, sostituisci le icone in public/ e app.json. Non cambiare layout né logica.
