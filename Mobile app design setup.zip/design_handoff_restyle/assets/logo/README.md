# My command center — logo

Simbolo: "Quattro tessere", petali verso l'esterno.
Colori (TL, TR, BR, BL): eucalipto, rosa borgogna, eucalipto, sabbia.

| Tema | Fondo icona | Eucalipto | Borgogna | Sabbia | Testo |
|---|---|---|---|---|---|
| Chiaro | #F3EEE7 | #7C8C6E | #A14A5A | #D8C6B0 | #2F2A27 |
| Scuro | #222822 (background element) | #A3B592 | #B35F6D | #E1CFB8 | #ECEAE2 |

Il nome è in Cormorant Garamond 600, convertito in tracciati (non serve il font installato).

## Cartelle
- svg/: simbolo, icona con angoli al 22%, logo con nome su due righe e su una riga, in chiaro e scuro
- png/: apple-touch-icon 180, PWA 192/512 (standard e maskable), simbolo a 1024, logo con nome @2x
- favicon/: favicon.svg (cambia tra chiaro e scuro in automatico), .ico, 16/32, apple-touch-icon.png

## HTML <head>
```html
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon.ico" sizes="any">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<meta name="theme-color" content="#F3EEE7" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#222822" media="(prefers-color-scheme: dark)">
```

## manifest.webmanifest (icons)
```json
"icons": [
  { "src": "/icons/icon-192-light.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
  { "src": "/icons/icon-512-light.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
  { "src": "/icons/icon-maskable-192-light.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
  { "src": "/icons/icon-maskable-512-light.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
]
```
Le icone "-dark" sono pronte se preferisci l'icona scura come predefinita (il manifest non cambia icona in base al tema).
